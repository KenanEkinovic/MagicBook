In MagicBook android app change the IP adress in the ApiConnector class to the IP adress to the IP of server and compile to get the correct .apk file.
	(open project MagicBook in Android Studio in order to change that)
The MagicBook admin app is located on that server.